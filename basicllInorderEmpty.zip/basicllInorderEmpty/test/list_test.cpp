#define CATCH_CONFIG_MAIN

#include "catch/catch.hpp"
#include "../list.hpp"
#include <string>

TEST_CASE("Test insert and print")
{
	List scores;
}
